import React from 'react'
import FooterBottom from './components/FooterBottom'
import MainFooter from './components/MainFooter'
const Footer = () => {
  return (
<>
<MainFooter/>
</>  )
}

export default Footer