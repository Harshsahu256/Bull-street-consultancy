import React from 'react'

const FooterBottom = () => {
  return (
    <div>FooterBottom</div>
  )
}

export default FooterBottom