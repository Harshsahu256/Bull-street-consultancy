import React from "react";
import { FaRegEnvelope } from "react-icons/fa6";
import { IoCallOutline } from "react-icons/io5";
import { RiMapPin2Line } from "react-icons/ri";
import logo from "../../assets/footerlogo.png";
import { Link } from "react-router-dom";
const MainFooter = () => {
  return (
    <div>
      <div className=" ">
        <footer className="text-center text-lg-start bg-dark text-white">
          {/* style={{backgroundColor: "#1c2331"}} */}
          {/* <section
                 className="d-flex justify-content-between p-4"
               style={{backgroundColor: "#6351ce"}}
                 >
      
          <div className="me-5">
            <span>Get connected with us on social networks:</span>
          </div>
        
          <div>
            <Link to="" className="text-white me-4">
              <i className="fab fa-facebook-f"></i>
            </Link>
            <Link to="" className="text-white me-4">
              <i className="fab fa-twitter"></i>
            </Link>
            <Link to="" className="text-white me-4">
              <i className="fab fa-google"></i>
            </Link>
            <Link to="" className="text-white me-4">
              <i className="fab fa-instagram"></i>
            </Link>
            <Link to="" className="text-white me-4">
              <i className="fab fa-linkedin"></i>
            </Link>
            <Link to="" className="text-white me-4">
              <i className="fab fa-github"></i>
            </Link>
          </div>
        </section> */}

          <section className="pt-5">
            <div className="container-fluid text-center text-md-start mt-5">
              <div className="row mt-3">
                <div className="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                  <img
                    src={logo}
                    alt="Footer Logo"
                    height="80px"
                    width="280px"
                  />
                  {/* <h6 className="text-uppercase fw-bold">Company name</h6>
                <hr
                    className="mb-4 mt-0 d-inline-block mx-auto"
                    style={{width:"60px", backgroundColor:"#7c4dff", height:"2px"}}
                    /> */}
                  <p>
                    In the stock market, time is your ally, knowledge is your
                    power, and patience is your virtue. Embrace the
                    fluctuations, learn from the trends, and trust in your
                    strategy; for in the world of stocks, resilience leads to
                    rewards.
                  </p>
                </div>
                <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                  <h6 className="text-uppercase fw-bold">Firm</h6>
                  <hr
                    className="mb-4 mt-0 d-inline-block mx-auto"
                    style={{
                      width: "60px",
                      backgroundColor: "#7c4dff",
                      height: "2px",
                    }}
                  />
                  <p>
                    <Link to="/" className="text-white">
                      Home
                    </Link>
                  </p>
                  <p>
                    <Link to="/about" className="text-white">
                      About{" "}
                    </Link>
                  </p>
                  <p>
                    <Link to="/bank-detail" className="text-white">
                      Bank Detail
                    </Link>
                  </p>
                  <p>
                    <Link to="/package" className="text-white">
                      Package
                    </Link>
                  </p>
                  <p>
                    <Link to="/contact" className="text-white">
                      Contact
                    </Link>
                  </p>
                </div>
                <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                  <h6 className="text-uppercase fw-bold">Useful links</h6>
                  <hr
                    className="mb-4 mt-0 d-inline-block mx-auto"
                    style={{
                      width: "60px",
                      backgroundColor: "#7c4dff",
                      height: "2px",
                    }}
                  />
                  <p>
                    <Link to="/terms-and-condition" className="text-white">
                      Terms and Conditions
                    </Link>
                  </p>
                  <p>
                    <Link to="/privacy-policy" className="text-white">
                      Privacy Policy
                    </Link>
                  </p>
                  
                  <p>
                    <Link to="/return-refund" className="text-white">
                      Refund Policy
                    </Link>
                  </p>
                  <p>
                    <Link to="/disclosure" className="text-white">
                      Disclosure
                    </Link>
                  </p>
                </div>
                <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                  <h6 className="text-uppercase fw-bold">Contact</h6>
                  <hr
                    className="mb-4 mt-0 d-inline-block mx-auto"
                    style={{
                      width: "60px",
                      backgroundColor: "#7c4dff",
                      height: "2px",
                    }}
                  />
                  <p>
                    <RiMapPin2Line className="me-3" />Mumbai, Maharashtra 400708  </p>
                  <p>
                    <FaRegEnvelope className="me-3"/>
                    info@bullstreetconsultancy.in                  </p>
                  <p>
                  <IoCallOutline className="me-3"/> +91 9294556388
                  </p>
                  {/* <p>
                    <i className="fas fa-print mr-3"></i> + 01 234 567 89
                  </p> */}
                </div>
              </div>
            </div>
          </section>
          <div
            className="text-center p-3"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.2)" }}
          >
            © 2024 Copyright Bullstreet Consultancy. All Rights Reserved.
          </div>
        </footer>
      </div>
    </div>
  );
};

export default MainFooter;
