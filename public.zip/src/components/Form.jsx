import React, { useState } from 'react';

const Form = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    state: '',
    segment: '',
    investment: '',
    termsAccepted: false, // State to track if terms are accepted
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.termsAccepted) {
      alert('You must accept the terms and conditions');
      return;
    }
    console.log('Form Submitted', formData);
    // You can add further logic to submit the form data
  };

  return (
    <form onSubmit={handleSubmit}  style={{padding:"30px" ,border:"2px solid #fff " ,borderRadius:"5px"}}>
      <div className=''>
        <input  className=' my-2 px-3'
          type="text"
          id="name"
          name="name"
          placeholder='Name'
          value={formData.name}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <input className=' my-2 px-3'
          type="email"
          id="email"
          name="email"
          placeholder='Email'
          value={formData.email}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <input className=' my-2 px-3'
          type="tel"
          id="phone"
          name="phone"
          placeholder='Phone'
          value={formData.phone}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <select className=' my-2 px-3'
          id="state"
          name="state"
          value={formData.state}
          onChange={handleChange}
          required
        >
          <option value=""> State</option>
          <option value="California">California</option>
          <option value="Texas">Texas</option>
          <option value="New York">New York</option>
          <option value="Florida">Florida</option>
          {/* Add more states as needed */}
        </select>
      </div>

      <div>
        <select className=' my-2 px-3'
          id="segment"
          name="segment"
          value={formData.segment}
          onChange={handleChange}
          required
        >
          <option value="">Select Segment</option>
          <option value="Technology">Technology</option>
          <option value="Healthcare">Healthcare</option>
          <option value="Finance">Finance</option>
          <option value="Education">Education</option>
          {/* Add more segments as needed */}
        </select>
      </div>

      <div>
        <select className=' my-2 px-3'
          id="investment"
          name="investment"
          value={formData.investment}
          onChange={handleChange}
          required
        >
          <option value="">Select Investment Level</option>
          <option value="Under $10k">Under $10k</option>
          <option value="$10k - $50k">$10k - $50k</option>
          <option value="$50k - $100k">$50k - $100k</option>
          <option value="Over $100k">Over $100k</option>
        </select>
      </div>

      <div className=' mx-4 mt-2 '>
        <label className='d-flex flex-row justify-content-start text-white' >
          <input className='' style={{height:"30px" , width:"30px" , marginRight:"20px"}}
            type="checkbox"
            name="termsAccepted"
            checked={formData.termsAccepted}
            onChange={handleChange}
            required
          />
          I accept the <a className='text-white text-decoration-none'
           href="/terms-and-conditions" target="_blank" rel="noopener noreferrer"> Terms and Conditions</a>
        </label>
      </div>

      <button className=' my-2 p-3' type="submit" style={{borderRadius:"6px"}}>Contact Us</button>
    </form>
  );
};

export default Form;
