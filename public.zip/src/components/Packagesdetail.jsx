import React, { useEffect, useState } from "react";
import "../styles/Homestyle.css";
import { TiArrowRightOutline } from "react-icons/ti";
import { TiArrowLeftOutline } from "react-icons/ti";
import { TiArrowDownOutline } from "react-icons/ti";
const Packagesdetail = () => {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth<=789);
        window.addEventListener("resize" , handleResize) 
        return ()=>window.removeEventListener("resize" , handleResize)
      }, []);

  return (
    <>
      <div
        className="container-fluid paddingcustom"
        style={{ backgroundColor: "#ac1929" }}
      >
        <div className="container p-5">
          <h2 className="text-center text-white headingcommon pb-4">
            NIFTY PACKAGES
          </h2>

          <div className="row">
            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80">
              <div className="row">
                <div className="col-md-10 p-md-4 ps-3 col-12">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    NIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                    MINIMUM BUDGET ₹ 50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                    ₹ 13,500
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center">
                {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowRightOutline className="iconstyle" />}

                  {/* <TiArrowRightOutline className="iconstyle" />{" "} */}
                </div>
              </div>
            </div>

            <div className="col-md-6 col-12 p-md-5 ps-3 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                  One research alert of Nifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                  Every research alert will be provided with targets and stop
                  loss.
                </li>
                <li className="text-white headingPackageli">
                  Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>
          </div>

          <div className="row m-md-auto  mt-5">
            <div className="col-md-6 col-12 p-md-5 ps-3 order-md-1 order-2 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                  One research alert of Nifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                  Every research alert will be provided with targets and stop
                  loss.
                </li>
                <li className="text-white headingPackageli">
                  Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>

            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80 order-md-2 order-1">
              <div className="row">
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center order-md-1 order-2">
                  {/* <TiArrowLeftOutline className="iconstyle" />{" "} */}
                  {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowLeftOutline className="iconstyle" />}

                </div>
                <div className="col-md-10 p-md-4 ps-3 col-12 order-md-2 order-1">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    NIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                    MINIMUM BUDGET ₹ 50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                    ₹ 13,500
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

<hr style={{color:"white"}}/>

<div className="container p-5">
          <h2 className="text-center text-white headingcommon pb-4">
            NIFTY PACKAGES
          </h2>

          <div className="row">
            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80">
              <div className="row">
                <div className="col-md-10 p-md-4 ps-3 col-12">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    NIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                    MINIMUM BUDGET ₹ 50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                    ₹ 13,500
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center">
                  {/* <TiArrowRightOutline className="iconstyle" />{" "} */}
                  {
                  console.log(isMobile,"isMobile")}
                  {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowRightOutline className="iconstyle" />}
                </div>
              </div>
            </div>

            <div className="col-md-6 col-12 p-md-5 ps-3 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                  One research alert of Nifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                  Every research alert will be provided with targets and stop
                  loss.
                </li>
                <li className="text-white headingPackageli">
                  Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>
          </div>

          <div className="row m-md-auto  mt-5">
            <div className="col-md-6 col-12 p-md-5 ps-3 order-md-1 order-2 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                  One research alert of Nifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                  Every research alert will be provided with targets and stop
                  loss.
                </li>
                <li className="text-white headingPackageli">
                  Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>

            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80 order-md-2 order-1">
              <div className="row">
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center order-md-1 order-2">
                {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowLeftOutline className="iconstyle" />}

                  {/* <TiArrowLeftOutline className="iconstyle" />{" "} */}
                </div>
                <div className="col-md-10 p-md-4 ps-3 col-12 order-md-2 order-1">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    NIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                    MINIMUM BUDGET ₹ 50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                    ₹ 13,500
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
<hr style={{color:"white"}}/>

<div className="container p-5">
          <h2 className="text-center text-white headingcommon pb-4">
          BANKNIFTY PACKAGES
          </h2>

          <div className="row">
            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80">
              <div className="row">
                <div className="col-md-10 p-md-4 ps-3 col-12">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    BANKNIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                  MINIMUM BUDGET ₹ 75,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                    ₹ 30,000
                  </h2>
                  <p className="headingpackage headingPackagePara">
                  *All Prices are inclusive
                  </p>
                </div>
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center">
                  {/* <TiArrowRightOutline className="iconstyle" />{" "} */}
                  {
                  console.log(isMobile,"isMobile")}
                  {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowRightOutline className="iconstyle" />}
                </div>
              </div>
            </div>

            <div className="col-md-6 col-12 p-md-5 ps-3 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                One research alert of Bank Nifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                Every research alert will be provided with targets and stop loss.
                </li>
                <li className="text-white headingPackageli">
                Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>
          </div>

          <div className="row m-md-auto  mt-5">
            <div className="col-md-6 col-12 p-md-5 ps-3 order-md-1 order-2 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                More than two research alert Bank Nifty Intraday Tips.                </li>
                <li className="text-white headingPackageli">
                Expiry Special on Wednesday
                </li>
                <li className="text-white headingPackageli">
                Live Support available
                </li>
                <li className="text-white headingPackageli">
                Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>

            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80 order-md-2 order-1">
              <div className="row">
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center order-md-1 order-2">
                {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowLeftOutline className="iconstyle" />}

                  {/* <TiArrowLeftOutline className="iconstyle" />{" "} */}
                </div>
                <div className="col-md-10 p-md-4 ps-3 col-12 order-md-2 order-1">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    BANKNIFTY PREMIUM{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                  MINIMUM BUDGET ₹ 1,50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                  ₹ 75,000
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
<hr style={{color:"white"}}/>

<div className="container p-5">
          <h2 className="text-center text-white headingcommon pb-4">
          FINNIFTY PACKAGES
          </h2>

          <div className="row">
            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80">
              <div className="row">
                <div className="col-md-10 p-md-4 ps-3 col-12">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    FINNIFTY STANDARD{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                  MINIMUM BUDGET ₹ 50,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                  ₹ 12,000
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center">
                  {/* <TiArrowRightOutline className="iconstyle" />{" "} */}
                  {
                  console.log(isMobile,"isMobile")}
                  {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowRightOutline className="iconstyle" />}
                </div>
              </div>
            </div>

            <div className="col-md-6 col-12 p-md-5 ps-3 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                  Live Support available
                </li>
                <li className="text-white headingPackageli">
                One research alert of FinNifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                Every research alert will be provided with targets and stop loss.
                </li>
                <li className="text-white headingPackageli">
                Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>
          </div>

          <div className="row m-md-auto  mt-5">
            <div className="col-md-6 col-12 p-md-5 ps-3 order-md-1 order-2 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                More than two research alert FinNifty Intraday Tips.
                </li>
                <li className="text-white headingPackageli">
                Expiry Special on Tuesday
                </li>
                <li className="text-white headingPackageli">
                Live Support available
                </li>
                <li className="text-white headingPackageli">
                Risk Level – High to Very High
                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>

            <div className="col-md-6 col-12  bg-white p-md-5 ps-3  pad-80 order-md-2 order-1">
              <div className="row">
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center order-md-1 order-2">
                {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowLeftOutline className="iconstyle" />}

                  {/* <TiArrowLeftOutline className="iconstyle" />{" "} */}
                </div>
                <div className="col-md-10 p-md-4 ps-3 col-12 order-md-2 order-1">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    FINNIFTY PREMIUM{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                  MINIMUM BUDGET ₹ 1,00,000
                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                  ₹ 42,000
                  </h2>
                  <p className="headingpackage headingPackagePara">
                  *All Prices are inclusive
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr style={{color:"white"}}/>

<div className="container p-5">
          <h2 className="text-center text-white headingcommon pb-4">
          Index Option (Combo Package)
          </h2>

          <div className="row">
            <div className="col-md-6 col-12  bg-white p-md-5  pe-md-0 ps-3  pad-80  d-flex flex-column justify-content-center align-items-center">
              <div className="row ">
                <div className="col-md-10 p-md-2 pe-md-2 ps-3 pe-0 col-12 my-auto">
                  <h4 className=" headingpackage headingpackageFont ">
                    {" "}
                    Combo Package{" "}
                  </h4>
                  <p className="headingpackage headingpackageFontpara">
                  MINIMUM BUDGET ₹ 3,00,000                  </p>

                  <h2 className="headingpackage headingpackageFontprice">
                  ₹2,75,000
                  </h2>
                  <p className="headingpackage headingPackagePara">
                    *All Prices are inclusive
                  </p>
                </div>
                <div className="col-md-2 col-12 d-flex justify-content-center align-self-center">
                  {/* <TiArrowRightOutline className="iconstyle" />{" "} */}
                  {
                  console.log(isMobile,"isMobile")}
                  {isMobile ? <TiArrowDownOutline className="iconstyle" /> : <TiArrowRightOutline className="iconstyle" />}
                </div>
              </div>
            </div>

            <div className="col-md-6 col-12 p-md-5 ps-3 bg-dark pad-80 d-flex justify-content-center align-content-center aling-items-center flex-column ">
              <ul className="">
                <li className="text-white headingPackageli">
                Get two to three research alert per day through WhatsApp broadcast message.
                </li>
                <li className="text-white headingPackageli">
                Get one to two research alerts of Bank Nifty Option or Nifty Option per day.
                </li>
                <li className="text-white headingPackageli">
                Get one to two research alerts of Finnifty every week.
                </li>
                <li className="text-white headingPackageli">
                Get one to two research alerts of Bankex or Sensex every week.
                </li>
                <li className="text-white headingPackageli">
                Get Expiry Special research alerts on every weekly expiry.                </li>
                <li className="text-white headingPackageli">
                Get well –researched target & Stop loss on every research alert.                </li>
                <li className="text-white headingPackageli">
                Live Market customer support is available                </li>
                <li className="text-white headingPackageli">
                Risk level – High to Very High                </li>
              </ul>
              <button className="mb-md-4 mb-0 fontstylecss btnpackage">
                Enquire Now
              </button>
            </div>
          </div>

      
        </div>
      </div>
    </>
  );
};

export default Packagesdetail;
