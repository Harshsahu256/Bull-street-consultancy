import React from 'react'

const WhyBull = () => {
  return (
    <div>WhyBull</div>
  )
}

export default WhyBull