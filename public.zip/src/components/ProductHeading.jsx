import React from 'react'

const ProductHeading = ({title , description}) => {
  return (
    <div className='container my-5'>
  <h2 className="headingcommon redheading text-center ">{title}</h2>
            <div
              className="mb-4 mt-0 d-inline-block "
              style={{
                width: "100%",
                backgroundColor: "#ac1929",
                height: "1px",
              }}
            />
            <p style={{textAlign:"justify"}}>
            {description}
            </p>
          

    </div>
  )
}

export default ProductHeading
