import React from "react";
import Form from "./Form";

const Contact1 = () => {
  return (
    <div className="bgimagecontact formcss py-5 my-5">
      <div className="container">
        <div className="row ">
          <div className="col-md-6 col-12 d-flex flex-column justify-content-center align-content-center ">
            <h4
              className="text-white mb-3 headingbanner"
              style={{ fontWeight: 600 }}
            >
              Office Business hours{" "}
            </h4>

            <p className="text-white bannerpara">
              9 Am to 6 Pm, Monday to Saturday{" "}
            </p>
            <div
              className="mb-4 mt-4 d-inline-block "
              style={{
                width: "90px",
                backgroundColor: "#fff",
                height: "3px",
              }}
            />

            <h4
              className="text-white mb-3 headingbanner"
              style={{ fontWeight: 600 }}
            >
              Customer support{" "}
            </h4>

            <p className="text-white bannerpara">
            +91 9294556388{" "}
            </p>
            <div
              className="mb-4 mt-4 d-inline-block "
              style={{
                width: "90px",
                backgroundColor: "#fff",
                height: "3px",
              }}
            />

            <h4
              className="text-white mb-3 headingbanner"
              style={{ fontWeight: 600 }}
            >
             Email Us{" "}
            </h4>

            <p className="text-white bannerpara">
            info@bullstreetconsultancy.in{" "}
            </p>
            <div
              className="mb-4 mt-4 d-inline-block "
              style={{
                width: "90px",
                backgroundColor: "#fff",
                height: "3px",
              }}
            />

            <h4
              className="text-white mb-3 headingbanner"
              style={{ fontWeight: 600 }}
            >
             Address{" "}
            </h4>

            <p className="text-white bannerpara">
            Mumbai, Maharashtra 400708{" "}
            </p>
            <div
              className="mb-4 mt-4 d-inline-block "
              style={{
                width: "90px",
                backgroundColor: "#fff",
                height: "3px",
              }}
            />
          </div>
          <div className="col-md-6 col-12 d-flex flex-column justify-content-center align-content-center align-items-center">
          <h4 className='text-white headingbanner'>Have any Queries? </h4>
        <div
          className="mb-4 mt-4 d-inline-block "
          style={{
            width: "90px",
            backgroundColor: "#fff",
            height: "3px",
          }}
        />
        
            <Form />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact1;
