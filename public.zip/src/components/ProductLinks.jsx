import React from 'react'
import { Link } from 'react-router-dom'

const ProductLinks = () => {
  return (
    <div  className='container-fluid m-0 p-0' > 
      
    <div className='bgimageproduct d-flex justify-content-center align-items-center' style={{height:"500px", }}>
<div className='row justify-content-around align-content-center pt-5'>
    <p className='col-md-5 bg-danger text-white product-heading mx-md-5 text-center rounded-5'><Link className='text-white text-decoration-none' to="/products/equity">Equity </Link></p>
    <p className='col-md-5 bg-danger text-white product-heading mx-md-5 text-center rounded-5'><Link className='text-white text-decoration-none' to="/products/currency-derivatives">Currency Derivatives </Link></p>
    <p className='col-md-5 bg-danger text-white product-heading mx-md-5 text-center rounded-5'><Link className='text-white text-decoration-none' to="/products/mutual-funds">Mutual Funds </Link></p>
    <p className='col-md-5 bg-danger text-white product-heading mx-md-5 text-center rounded-5'><Link className='text-white text-decoration-none' to="/products/ipo">IPO </Link></p>
    <p className='col-md-5 bg-danger text-white product-heading mx-md-5 text-center rounded-5'><Link className='text-white text-decoration-none' to="/products/equity-derivatives">Equity Derivatives </Link></p>
</div>

    </div>
    </div>
  )
}

export default ProductLinks
