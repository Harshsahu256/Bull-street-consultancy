import React from 'react'
import { Breadcum } from '../components/Breadcum'
import Contact1 from '../components/Contact1'
import MarqueePara from '../components/MarqueePara'

const Contact = () => {
  return (
    <div>
        <Breadcum title={"Contact"}/>
        {/* <MarqueePara/> */}
<Contact1/>
    </div>
  )
}

export default Contact