import React from 'react'
import '../styles/Product.css';

const Product = () => {
  return (
    <div className='bgimageproduct' style={{height:"500px", }}>
      <h1>fdfk</h1>
    </div>
  )
}

export default Product
