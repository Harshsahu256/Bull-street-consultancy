import React from 'react'
import { Breadcum } from '../components/Breadcum'
import Packagesdetail from '../components/Packagesdetail'
import ConnectWithus from '../components/ConnectWithus'
import MarqueePara from '../components/MarqueePara'

const Packages = () => {
  return (<>
    <Breadcum title={"Package"} />
    <MarqueePara/>
    <Packagesdetail/>
    <ConnectWithus/>
    </>
  )
}

export default Packages