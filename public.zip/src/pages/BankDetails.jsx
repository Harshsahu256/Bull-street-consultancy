import React from "react";
import { Breadcum } from "../components/Breadcum";
import MarqueePara from "../components/MarqueePara";

const BankDetails = () => {
  return (
    <>
      <Breadcum title={"Bank Detail"} />
      <MarqueePara/>
      <div className="container my-5">
        <h4
          className=" mb-3 headingbanner redheading"
          style={{ fontWeight: 600 }}
        >
          Bank Details: –
        </h4>

        <div
          className="mb-4 mt-4 d-inline-block "
          style={{
            width: "90px",
            backgroundColor: "#ac1929",
            height: "3px",
          }}
        />



<div className="row">
  <div className="col-md-3 col-6">
  <p className='bankpara'>Payee Name  :</p>
  </div>
  
  <div className="col-md-9 col-6">
  <p className='bankpara'> </p>
  </div>
</div>
<div className="row">
  <div className="col-md-3 col-6">
  <p className=' bankpara'>UPI ID   :</p>
  </div>
  
  <div className="col-md-9 col-6">
  <p className='bankpara'> </p>
  </div>
</div><div className="row">
  <div className="col-md-3 col-6">
  <p className='bankpara'>Pay Now  :</p>
  </div>
  
  <div className="col-md-9 col-6">
  <a className='tex-dark text-decoration-none bankpara' href=""> </a>
  </div>
</div>

      </div>
    </>
  );
};

export default BankDetails;
