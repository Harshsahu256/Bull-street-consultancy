import React from 'react'
import About1 from '../components/About1'
import { Breadcum } from '../components/Breadcum'
import ConnectWithus from '../components/ConnectWithus'
import MarqueePara from '../components/MarqueePara'
import Mission from '../components/Mission'

const About = () => {
  return (
  <>
<Breadcum title={"About"}/>
{/* <MarqueePara/>
 */}
  <About1/>
  <Mission/>
  <ConnectWithus/>
  </>
  )
}

export default About