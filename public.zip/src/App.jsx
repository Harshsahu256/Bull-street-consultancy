import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'; // Import Route here
import Home from './pages/Home'
import RouteScrollToTop from './helper/RouteScrollToTop';
import Header from './headerfooter/Header'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import Footer from './headerfooter/Footer';
import './styles/common.css'
import About from './pages/About';
import Packages from './pages/Packages';
import Contact from './pages/Contact';
import BankDetails from './pages/BankDetails';
import TermsCondition from './pages/TermsCondition';
import PrivacyPolicy from './pages/PrivacyPolicy';
import Return from './pages/Return';
import Disclouse from './pages/Disclouse';
import PageNotFound from './pages/PageNotFound';
import Product from './pages/Product';
import Equity from './pages/Equity';
import CurrencyDerivatives from './pages/CurrencyDerivatives';
import Ipo from './pages/Ipo';
import MutualFund from './pages/MutualFund';
import EquityDerivatives from './pages/EquityDerivatives';
// #ac1929
const App = () => {
  return (
   <>
   <BrowserRouter>
   <RouteScrollToTop/>
   <Header/>
   <Routes>
    <Route exact path="/" element={<Home />} />
    <Route exact path="/about" element={<About />} />
    <Route exact path="/package" element={<Packages />} />
    <Route exact path="/contact" element={<Contact />} />
    <Route exact path="/bank-detail" element={<BankDetails />} />
    <Route exact path="/terms-and-condition" element={<TermsCondition />} />
    <Route exact path="/privacy-policy" element={<PrivacyPolicy />} />    
    <Route exact path="/return-refund" element={<Return />} />
    <Route exact path="/disclosure" element={<Disclouse />} />
    <Route exact path="/products/equity" element={<Equity />} />
    <Route exact path="/products/currency-derivatives" element={<CurrencyDerivatives />} />
    <Route exact path="/products/ipo" element={<Ipo />} />
    <Route exact path="/products/mutual-funds" element={<MutualFund />} />
    <Route exact path="/products/equity-derivatives" element={<EquityDerivatives />} />
    
    <Route exact path="*" element={<PageNotFound />} />
   </Routes>
<Footer/>
   </BrowserRouter>
   </>
  )
}

export default App