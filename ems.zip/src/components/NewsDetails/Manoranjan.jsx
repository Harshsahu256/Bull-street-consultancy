




// import React, { useEffect, useState } from 'react';
// import { Container, Row, Col, Image, Spinner, Alert } from 'react-bootstrap';
// import { FaArrowRight } from 'react-icons/fa';
// import { allNews } from '../../Services/authApi';
// import { Link } from 'react-router-dom';

// const Manoranjan = () => {
//     const [newsData, setNewsData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // useEffect, Loading, Error, No Data states... (No Changes Here)
//     useEffect(() => {
//         const fetchNews = async () => {
//             setLoading(true);
//             try {
//                 const res = await allNews();
//                 if (res?.success) {
//                     const entertainmentNews = res.data.filter((item) => {
//                         const categoryName = item.category?.name?.toLowerCase() || '';
//                         return categoryName === "entertainment" || categoryName === "मनोरंजन";
//                     });
//                     setNewsData(entertainmentNews);
//                 } else {
//                     setError("Failed to load news");
//                 }
//             } catch (err) {
//                 setError(err.message || "An error occurred");
//             } finally {
//                 setLoading(false);
//             }
//         };
//         fetchNews();
//     }, []);

//     if (loading) { /* ... Loading UI ... */ }
//     if (error) { /* ... Error UI ... */ }
//     if (newsData.length === 0) { /* ... No Data UI ... */ }
    
//     const mainArticle = newsData[0];
//     const bottomArticle = newsData[1];
//     const sideArticles = newsData.slice(2, 6);
//     const linkStyle = { textDecoration: 'none', color: 'inherit' };

//     return (
//         <Container fluid className="mt-4">
//             {/* Section Header */}
//             <div style={{ width: '40px', height: '4px', backgroundColor: '#F8D7DA', marginBottom: '8px' }}></div>
//             <div className="d-flex align-items-center mb-3">
//                 <div className="d-flex align-items-center flex-shrink-0">
//                     <div style={{ width: '5px', height: '24px', backgroundColor: '#A12D2A' }} className="me-2"></div>
//                     <h5 className="fw-bold m-0">मनोरंजन</h5>
//                 </div>
//                 <hr className="flex-grow-1 mx-3" style={{ borderTop: '2px solid #A12D2A', opacity: 1 }} />
//                 <Link to="/entertainment" className="text-decoration-none fw-bold small flex-shrink-0" style={{ color: '#A12D2A' }}>
//                     और पढ़ें <FaArrowRight size={12} />
//                 </Link>
//             </div>

//             {/* Content Grid */}
//             <Row>
//                 {/* Left Column */}
//                 <Col lg={7} className="mb-4 mb-lg-0 d-lg-flex flex-column">
//                     {/* Main Article */}
//                     {mainArticle && (
//                         <Link 
//                             to={`/news/${mainArticle._id}`} 
//                             state={{ relatedArticles: newsData }}
//                             style={linkStyle} 
//                             className="d-block position-relative mb-4 flex-grow-1"
//                         >
//                             <Image
//                                 src={mainArticle.media?.[0]?.url || "https://via.placeholder.com/600x400"}
//                                 fluid rounded
//                                 className="w-100 h-100"
//                                 style={{ objectFit: 'cover' }}
//                             />
//                             <div
//                                 className="position-absolute bottom-0 start-0 text-white w-100 p-3"
//                                 style={{
//                                     background: 'linear-gradient(to top, rgba(0,0,0,0.85) 40%, transparent)',
//                                     borderRadius: '0 0 var(--bs-border-radius) var(--bs-border-radius)'
//                                 }}
//                             >
//                                 <h4 className="fw-bold">{mainArticle.title}</h4>
//                                 {/* ✅ लेखक का नाम और तारीख यहाँ जोड़ा गया */}
//                                 <p className="small mb-0 opacity-75">
//                                     By {mainArticle.createdBy?.name || "EMS News"} | {new Date(mainArticle.createdAt).toLocaleDateString("hi-IN")}
//                                 </p>
//                             </div>
//                         </Link>
//                     )}

//                     {/* Bottom Article */}
//                     {bottomArticle && (
//                         <Link 
//                             to={`/news/${bottomArticle._id}`} 
//                             state={{ relatedArticles: newsData }}
//                             style={linkStyle}
//                         >
//                             <Row className="align-items-center">
//                                 <Col xs={4} md={3}>
//                                     <Image
//                                         src={bottomArticle.media?.[0]?.url || "https://via.placeholder.com/120x80"}
//                                         fluid rounded
//                                     />
//                                 </Col>
//                                 <Col xs={8} md={9} className="ps-2">
//                                     <div>
//                                         <p className="fw-bold mb-1">{bottomArticle.title}</p>
//                                         {/* ✅ लेखक का नाम और तारीख/समय यहाँ भी जोड़ा गया */}
//                                         <p className="text-muted small m-0">
//                                             By {bottomArticle.createdBy?.name || "EMS News"} | {new Date(bottomArticle.createdAt).toLocaleString("hi-IN")}
//                                         </p>
//                                     </div>
//                                 </Col>
//                             </Row>
//                         </Link>
//                     )}
//                 </Col>

//                 {/* Right Column */}
//                 <Col lg={5}>
//                     {sideArticles.map((article, index) => (
//                         <React.Fragment key={article._id}>
//                             <Link 
//                                 to={`/news/${article._id}`} 
//                                 state={{ relatedArticles: newsData }}
//                                 style={linkStyle}
//                             >
//                                 <Row className="align-items-center">
//                                     <Col xs={4}>
//                                         <Image
//                                             src={article.media?.[0]?.url || "https://via.placeholder.com/120x80"}
//                                             fluid rounded
//                                         />
//                                     </Col>
//                                     <Col xs={8} className="ps-2">
//                                         <div>
//                                             <p className="fw-bold mb-1" style={{ fontSize: '0.9rem', lineHeight: '1.4' }}>{article.title}</p>
//                                             {/* ✅ लेखक का नाम और तारीख/समय यहाँ भी जोड़ा गया */}
//                                             <p className="text-muted small m-0">
//                                                 By {article.createdBy?.name || "EMS News"} | {new Date(article.createdAt).toLocaleString("hi-IN")}
//                                             </p>
//                                         </div>
//                                     </Col>
//                                 </Row>
//                             </Link>
//                             {index < sideArticles.length - 1 && <hr className="my-3" />}
//                         </React.Fragment>
//                     ))}
//                 </Col>
//             </Row>
//         </Container>
//     );
// };

// export default Manoranjan;



// import React, { useEffect, useState } from 'react';
// import { Container, Row, Col, Image, Spinner, Alert } from 'react-bootstrap';
// import { FaArrowRight } from 'react-icons/fa';
// import { allNews } from '../../Services/authApi';
// import { Link } from 'react-router-dom';
// import UserAvatar from '../Main_NewsDetails/UserAvatar';

// const Manoranjan = () => {
//     const [newsData, setNewsData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         const fetchNews = async () => {
//             setLoading(true);
//             try {
//                 const res = await allNews();
//                 if (res?.success) {
//                     const entertainmentNews = res.data.filter(item => {
//                         const categoryName = item.category?.name?.toLowerCase() || '';
//                         return categoryName === "entertainment" || categoryName === "मनोरंजन";
//                     });
//                     setNewsData(entertainmentNews);
//                 } else {
//                     setError("Failed to load news");
//                 }
//             } catch (err) {
//                 setError(err.message || "An error occurred");
//             } finally {
//                 setLoading(false);
//             }
//         };
//         fetchNews();
//     }, []);

//     if (loading) return <div className="text-center my-4"><Spinner animation="border" /></div>;
//     if (error) return <Alert variant="danger" className="my-4">{error}</Alert>;
//     if (newsData.length === 0) return null;

//     const mainArticle = newsData[0];
//     const bottomArticle = newsData[1];
//     const sideArticles = newsData.slice(2, 6);
//     const linkStyle = { textDecoration: 'none', color: 'inherit' };

//     return (
//         <Container fluid className="mt-4">
//             <div style={{ width: '40px', height: '4px', backgroundColor: '#F8D7DA', marginBottom: '8px' }}></div>
//             <div className="d-flex align-items-center mb-3">
//                 <div className="d-flex align-items-center flex-shrink-0">
//                     <div style={{ width: '5px', height: '24px', backgroundColor: '#A12D2A' }} className="me-2"></div>
//                     <h5 className="fw-bold m-0">मनोरंजन</h5>
//                 </div>
//                 <hr className="flex-grow-1 mx-3" style={{ borderTop: '2px solid #A12D2A', opacity: 1 }} />
//                 <Link to="/entertainment" className="text-decoration-none fw-bold small flex-shrink-0" style={{ color: '#2E6E9E' }}>
//                     और पढ़ें <FaArrowRight size={12} />
//                 </Link>
//             </div>

//             <Row>
//                 <Col lg={7} className="mb-4 mb-lg-0 d-lg-flex flex-column">
//                     {mainArticle && (
//                         <Link to={`/news/${mainArticle._id}`} state={{ relatedArticles: newsData }} style={linkStyle} className="d-block position-relative mb-4 flex-grow-1">
//                             <Image src={mainArticle.media?.[0]?.url || "https://via.placeholder.com/600x400"} fluid rounded className="w-100 h-100" style={{ objectFit: 'cover' }} />
//                             <div className="position-absolute bottom-0 start-0 text-white w-100 p-3" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.85) 40%, transparent)', borderRadius: '0 0 var(--bs-border-radius) var(--bs-border-radius)' }}>
//                                 <h4 className="fw-bold">{mainArticle.title}</h4>
//                                 <div className="d-flex align-items-center mt-1">
//                                     <UserAvatar user={mainArticle.createdBy} size={30} />
//                                     <small className="ms-2">
//                                         {mainArticle.createdBy?.name || "EMS News"} | {new Date(mainArticle.createdAt).toLocaleDateString("hi-IN")}
//                                     </small>
//                                 </div>
//                             </div>
//                         </Link>
//                     )}

//                     {bottomArticle && (
//                         <Link to={`/news/${bottomArticle._id}`} state={{ relatedArticles: newsData }} style={linkStyle}>
//                             <Row className="align-items-center">
//                                 <Col xs={4} md={3}>
//                                     <Image src={bottomArticle.media?.[0]?.url || "https://via.placeholder.com/120x80"} fluid rounded />
//                                 </Col>
//                                 <Col xs={8} md={9} className="ps-2">
//                                     <p className="fw-bold mb-1">{bottomArticle.title}</p>
//                                     <div className="d-flex align-items-center">
//                                         <UserAvatar user={bottomArticle.createdBy} size={25} />
//                                         <small className="ms-2 text-muted">{bottomArticle.createdBy?.name || "EMS News"} | {new Date(bottomArticle.createdAt).toLocaleDateString("hi-IN")}</small>
//                                     </div>
//                                 </Col>
//                             </Row>
//                         </Link>
//                     )}
//                 </Col>

//                 <Col lg={5}>
//                     {sideArticles.map((article, index) => (
//                         <React.Fragment key={article._id}>
//                             <Link to={`/news/${article._id}`} state={{ relatedArticles: newsData }} style={linkStyle}>
//                                 <Row className="align-items-center">
//                                     <Col xs={4}>
//                                         <Image src={article.media?.[0]?.url || "https://via.placeholder.com/120x80"} fluid rounded />
//                                     </Col>
//                                     <Col xs={8} className="ps-2">
//                                         <p className="fw-bold mb-1" style={{ fontSize: '0.9rem', lineHeight: '1.4' }}>{article.title}</p>
//                                         <div className="d-flex align-items-center">
//                                             <UserAvatar user={article.createdBy} size={25} />
//                                             {/* <small className="ms-2 text-muted">{article.createdBy?.name || "EMS News"} | {new Date(article.createdAt).toLocaleDateString("hi-IN")}</small> */}
//                                             <small className="text-muted ms-1">
//                     {article.createdBy?.name || "EMS News"} |{" "}
//                     {new Date(article.createdAt).toLocaleString("hi-IN", {
//                       day: "numeric",
//                       month: "long",
//                       year: "numeric",
//                       hour: "2-digit",
//                       minute: "2-digit",
//                     })}
//                   </small>
//                                         </div>
//                                     </Col>
//                                 </Row>
//                             </Link>
//                             {index < sideArticles.length - 1 && <hr className="my-3" />}
//                         </React.Fragment>
//                     ))}
//                 </Col>
//             </Row>
//         </Container>
//     );
// };

// export default Manoranjan;



// import React, { useEffect, useState } from 'react';
// import { Container, Row, Col, Image, Spinner, Alert } from 'react-bootstrap';
// import { FaArrowRight } from 'react-icons/fa';
// import { allNews } from '../../Services/authApi';
// import { Link } from 'react-router-dom';
// import UserAvatar from '../Main_NewsDetails/UserAvatar';

// const Manoranjan = () => {
//     const [newsData, setNewsData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         const fetchNews = async () => {
//             setLoading(true);
//             try {
//                 const res = await allNews();
//                 if (res?.success) {
//                     const entertainmentNews = res.data.filter(item => {
//                         const categoryName = item.category?.name?.toLowerCase() || '';
//                         return categoryName === "entertainment" || categoryName === "मनोरंजन";
//                     });
//                     setNewsData(entertainmentNews);
//                 } else {
//                     setError("Failed to load news");
//                 }
//             } catch (err) {
//                 setError(err.message || "An error occurred");
//             } finally {
//                 setLoading(false);
//             }
//         };
//         fetchNews();
//     }, []);

//     if (loading) return <div className="text-center my-4"><Spinner animation="border" /></div>;
//     if (error) return <Alert variant="danger" className="my-4">{error}</Alert>;
//     if (newsData.length === 0) return null;

//     const mainArticle = newsData[0];
//     const bottomArticle = newsData[1];
//     const sideArticles = newsData.slice(2, 6);
//     const linkStyle = { textDecoration: 'none', color: 'inherit' };

//     return (
//         <Container fluid className="mt-4">
//             <div style={{ width: '40px', height: '4px', backgroundColor: '#F8D7DA', marginBottom: '8px' }}></div>
//             <div className="d-flex align-items-center mb-3 flex-wrap">
//                 <div className="d-flex align-items-center flex-shrink-0 mb-2 mb-sm-0">
//                     <div style={{ width: '5px', height: '24px', backgroundColor: '#A12D2A' }} className="me-2"></div>
//                     <h5 className="fw-bold m-0">मनोरंजन</h5>
//                 </div>
//                 <hr className="flex-grow-1 mx-2 mx-sm-3 border-danger border-2 opacity-100 my-0" />
//                 <Link to="/entertainment" className="text-decoration-none fw-bold small flex-shrink-0" style={{ color: '#2E6E9E' }}>
//                  और देखें <FaArrowRight size={12} />
//                 </Link>
//             </div>

//             <Row>
//                 {/* Left Column */}
//                 <Col lg={7} className="mb-4 mb-lg-0 d-lg-flex flex-column">
//                     {mainArticle && (
//                         <Link to={`/news/${mainArticle._id}`} state={{ relatedArticles: newsData }} style={linkStyle} className="d-block position-relative mb-4 flex-grow-1">
//                             <Image 
//                                 src={mainArticle.media?.[0]?.url || "https://via.placeholder.com/600x400"} 
//                                 fluid rounded className="w-100 h-100" 
//                                 style={{ objectFit: 'cover' }} 
//                             />
//                             <div className="position-absolute bottom-0 start-0 text-white w-100 p-3" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.85) 40%, transparent)', borderRadius: '0 0 var(--bs-border-radius) var(--bs-border-radius)' }}>
//                                 <h4 className="fw-bold">{mainArticle.title}</h4>
//                                 <div className="d-flex align-items-center flex-wrap mt-1">
//                                     <UserAvatar user={mainArticle.createdBy} size={30} />
//                                     <small className="ms-2">
//                                         {mainArticle.createdBy?.name || "EMS News"} | {new Date(mainArticle.createdAt).toLocaleDateString("hi-IN")}
//                                     </small>
//                                 </div>
//                             </div>
//                         </Link>
//                     )}

//                     {bottomArticle && (
//                         <Link to={`/news/${bottomArticle._id}`} state={{ relatedArticles: newsData }} style={linkStyle}>
//                             <Row className="align-items-center gx-2">
//                                 <Col xs={4} md={3}>
//                                     <Image src={bottomArticle.media?.[0]?.url || "https://via.placeholder.com/120x80"} fluid rounded />
//                                 </Col>
//                                 <Col xs={8} md={9} className="ps-2">
//                                     <p className="fw-bold mb-1">{bottomArticle.title}</p>
//                                     <div className="d-flex align-items-center flex-wrap">
//                                         <UserAvatar user={bottomArticle.createdBy} size={25} />
//                                         <small className="ms-2 text-muted">{bottomArticle.createdBy?.name || "EMS News"} | {new Date(bottomArticle.createdAt).toLocaleDateString("hi-IN")}</small>
//                                     </div>
//                                 </Col>
//                             </Row>
//                         </Link>
//                     )}
//                 </Col>

//                 {/* Right Column */}
//                 <Col lg={5}>
//                     {sideArticles.map((article, index) => (
//                         <React.Fragment key={article._id}>
//                             <Link to={`/news/${article._id}`} state={{ relatedArticles: newsData }} style={linkStyle}>
//                                 <Row className="align-items-center gx-2 mb-3">
//                                     <Col xs={4}>
//                                         <Image src={article.media?.[0]?.url || "https://via.placeholder.com/120x80"} fluid rounded />
//                                     </Col>
//                                     <Col xs={8} className="ps-2">
//                                         <p className="fw-bold mb-1" style={{ fontSize: '0.9rem', lineHeight: '1.4' }}>{article.title}</p>
//                                         <div className="d-flex align-items-center flex-wrap">
//                                             <UserAvatar user={article.createdBy} size={25} />
//                                             <small className="text-muted ms-1">
//                                                 {article.createdBy?.name || "EMS News"} |{" "}
//                                                 {new Date(article.createdAt).toLocaleString("hi-IN", {
//                                                     day: "numeric",
//                                                     month: "long",
//                                                     year: "numeric",
//                                                     hour: "2-digit",
//                                                     minute: "2-digit",
//                                                 })}
//                                             </small>
//                                         </div>
//                                     </Col>
//                                 </Row>
//                             </Link>
//                         </React.Fragment>
//                     ))}
//                 </Col>
//             </Row>
//         </Container>
//     );
// };

// export default Manoranjan;



// import React, { useEffect, useState } from "react";
// import { Container, Row, Col, Image, Spinner, Alert } from "react-bootstrap";
// import { FaArrowRight } from "react-icons/fa";
// import { allNews } from "../../Services/authApi";
// import { Link } from "react-router-dom";
// import UserAvatar from "../Main_NewsDetails/UserAvatar";

// const Manoranjan = () => {
//   const [newsData, setNewsData] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchNews = async () => {
//       try {
//         setLoading(true);
//         const res = await allNews();
//         if (res?.success) {
//           const entertainmentNews = res.data.filter((item) => {
//             const categoryName = item.category?.name?.toLowerCase() || "";
//             return categoryName === "entertainment" || categoryName === "मनोरंजन";
//           });
//           setNewsData(entertainmentNews);
//         } else {
//           setError("Failed to load news");
//         }
//       } catch (err) {
//         setError(err.message || "An error occurred");
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchNews();
//   }, []);

//   // Loading & Error States
//   if (loading)
//     return (
//       <div className="text-center my-4">
//         <Spinner animation="border" />
//       </div>
//     );
//   if (error) return <Alert variant="danger">{error}</Alert>;
//   if (!newsData.length) return null;

//   const mainArticle = newsData[0];
//   const bottomArticle = newsData[1];
//   const sideArticles = newsData.slice(2, 6);

//   const linkStyle = { textDecoration: "none", color: "inherit" };
//   const getDate = (date) =>
//     date
//       ? new Date(date).toLocaleString("hi-IN", {
//           day: "numeric",
//           month: "long",
//           year: "numeric",
//           hour: "2-digit",
//           minute: "2-digit",
//         })
//       : "";

//   return (
//     <Container fluid className="mt-4">
//       {/* Section Header */}
//       <div
//         style={{
//           width: "40px",
//           height: "4px",
//           backgroundColor: "#F8D7DA",
//           marginBottom: "8px",
//         }}
//       ></div>
//       <div className="d-flex align-items-center mb-3 flex-wrap">
//         <div className="d-flex align-items-center flex-shrink-0 mb-2 mb-sm-0">
//           <div
//             style={{ width: "5px", height: "24px", backgroundColor: "#A12D2A" }}
//             className="me-2"
//           ></div>
//           <h5 className="fw-bold m-0">मनोरंजन</h5>
//         </div>
//         <hr className="flex-grow-1 mx-2 mx-sm-3 border-danger border-2 opacity-100 my-0" />
//         <Link
//           to="/entertainment"
//           className="text-decoration-none fw-bold small flex-shrink-0"
//           style={{ color: "#2E6E9E" }}
//         >
//           और देखें <FaArrowRight size={12} />
//         </Link>
//       </div>

//       <Row>
//         {/* Left Column */}
//         <Col lg={7} className="mb-4 mb-lg-0 d-lg-flex flex-column">
//           {mainArticle && (
//             <Link
//               to={`/news/${mainArticle.slug_en}`} // ✅ Slug used
//               key={mainArticle._id}
//               state={{ relatedArticles: newsData }}
//               style={linkStyle}
//               className="d-block position-relative mb-4 flex-grow-1"
//             >
//               <Image
//                 src={
//                   mainArticle.media?.[0]?.url ||
//                   "https://via.placeholder.com/600x400"
//                 }
//                 fluid
//                 rounded
//                 className="w-100"
//                 style={{ objectFit: "cover", maxHeight: "400px" }}
//               />
//               <div
//                 className="position-absolute bottom-0 start-0 text-white w-100 p-3"
//                 style={{
//                   background:
//                     "linear-gradient(to top, rgba(0,0,0,0.85) 40%, transparent)",
//                   borderRadius:
//                     "0 0 var(--bs-border-radius) var(--bs-border-radius)",
//                 }}
//               >
//                 <h4 className="fw-bold">{mainArticle.title}</h4>
//                 <div className="d-flex align-items-center flex-wrap mt-1">
//                   <UserAvatar user={mainArticle.createdBy} size={30} />
//                   <small className="ms-2">
//                     {mainArticle.createdBy?.name || "EMS News"} |{" "}
//                     {getDate(mainArticle.createdAt)}
//                   </small>
//                 </div>
//               </div>
//             </Link>
//           )}

//           {bottomArticle && (
//             <Link
//               to={`/news/${bottomArticle.slug_en}`} // ✅ Slug used
//               key={bottomArticle._id}
//               state={{ relatedArticles: newsData }}
//               style={linkStyle}
//             >
//               <Row className="align-items-center gx-2">
//                 <Col xs={4} md={3}>
//                   <Image
//                     src={
//                       bottomArticle.media?.[0]?.url ||
//                       "https://via.placeholder.com/120x80"
//                     }
//                     fluid
//                     rounded
//                   />
//                 </Col>
//                 <Col xs={8} md={9} className="ps-2">
//                   <p className="fw-bold mb-1">{bottomArticle.title}</p>
//                   <div className="d-flex align-items-center flex-wrap">
//                     <UserAvatar user={bottomArticle.createdBy} size={25} />
//                     <small className="ms-2 text-muted">
//                       {bottomArticle.createdBy?.name || "EMS News"} |{" "}
//                       {getDate(bottomArticle.createdAt)}
//                     </small>
//                   </div>
//                 </Col>
//               </Row>
//             </Link>
//           )}
//         </Col>

//         {/* Right Column */}
//         <Col lg={5}>
//           {sideArticles.map((article) => (
//             <Link
//               to={`/news/${article.slug_en}`} // ✅ Slug used
//               key={article._id}
//               state={{ relatedArticles: newsData }}
//               style={linkStyle}
//             >
//               <Row className="align-items-center gx-2 mb-3">
//                 <Col xs={4}>
//                   <Image
//                     src={
//                       article.media?.[0]?.url ||
//                       "https://via.placeholder.com/120x80"
//                     }
//                     fluid
//                     rounded
//                   />
//                 </Col>
//                 <Col xs={8} className="ps-2">
//                   <p
//                     className="fw-bold mb-1"
//                     style={{ fontSize: "0.9rem", lineHeight: "1.4" }}
//                   >
//                     {article.title}
//                   </p>
//                   <div className="d-flex align-items-center flex-wrap">
//                     <UserAvatar user={article.createdBy} size={25} />
//                     <small className="text-muted ms-1">
//                       {article.createdBy?.name || "EMS News"} |{" "}
//                       {getDate(article.createdAt)}
//                     </small>
//                   </div>
//                 </Col>
//               </Row>
//             </Link>
//           ))}
//         </Col>
//       </Row>
//     </Container>
//   );
// };

// export default Manoranjan;
import React, { useEffect, useState } from "react";
import { Container, Row, Col, Image, Spinner, Alert } from "react-bootstrap";
import { FaArrowRight } from "react-icons/fa";
import { allNews } from "../../Services/authApi";
import { Link } from "react-router-dom";
import UserAvatar from "../Main_NewsDetails/UserAvatar";

const Manoranjan = () => {
  const [newsData, setNewsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        setLoading(true);
        const res = await allNews(); // ✅ API: allNews
        if (res?.success) {
          // ✅ Filter only entertainment category (Hindi & English)
          const entertainmentNews = res.data.filter((item) => {
            const categoryName = item.category?.name?.toLowerCase() || "";
            return categoryName === "entertainment" || categoryName === "मनोरंजन";
          });
          setNewsData(entertainmentNews);
        } else {
          setError("Failed to load news");
        }
      } catch (err) {
        setError(err.message || "An error occurred");
      } finally {
        setLoading(false);
      }
    };
    fetchNews();
  }, []);

  if (loading)
    return (
      <div className="text-center my-4">
        <Spinner animation="border" />
      </div>
    );
  if (error) return <Alert variant="danger">{error}</Alert>;
  if (!newsData.length) return null;

  const mainArticle = newsData[0];
  const bottomArticle = newsData[1];
  const sideArticles = newsData.slice(2, 6);

  const linkStyle = { textDecoration: "none", color: "inherit" };
  const getDate = (date) =>
    date
      ? new Date(date).toLocaleString("hi-IN", {
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "";

  return (
    <Container fluid className="mt-4">
      {/* Section Header */}
      <div style={{ width: "40px", height: "4px", backgroundColor: "#F8D7DA", marginBottom: "8px" }}></div>
      <div className="d-flex align-items-center mb-3 flex-wrap">
        <div className="d-flex align-items-center flex-shrink-0 mb-2 mb-sm-0">
          <div style={{ width: "5px", height: "24px", backgroundColor: "#A12D2A" }} className="me-2"></div>
          <h5 className="fw-bold m-0">मनोरंजन</h5>
        </div>
        <hr className="flex-grow-1 mx-2 mx-sm-3 border-danger border-2 opacity-100 my-0" />
        <Link to="/entertainment" className="text-decoration-none fw-bold small flex-shrink-0" style={{ color: "#2E6E9E" }}>
          और देखें <FaArrowRight size={12} />
        </Link>
      </div>

      <Row>
        {/* Left Column */}
        <Col lg={7} className="mb-4 mb-lg-0 d-lg-flex flex-column">
          {mainArticle && (
            <Link
              to={`/news/${mainArticle.slug_en}`} // ✅ API key changed: slug_en
              key={mainArticle.slug_en}
              state={{ relatedArticles: newsData }}
              style={linkStyle}
              className="d-block position-relative mb-4 flex-grow-1"
            >
              <Image
                src={mainArticle.media?.[0]?.url || "https://via.placeholder.com/600x400"} // ✅ API key: media[0].url
                fluid
                rounded
                className="w-100"
                style={{ objectFit: "cover", maxHeight: "400px" }}
              />
              <div className="position-absolute bottom-0 start-0 text-white w-100 p-3"
                style={{ background: "linear-gradient(to top, rgba(0,0,0,0.85) 40%, transparent)", borderRadius: "0 0 var(--bs-border-radius) var(--bs-border-radius)" }}
              >
                <h4 className="fw-bold">{mainArticle.title_hi || mainArticle.title_en}</h4> {/* ✅ API key: title_hi fallback title_en */}
                <div className="d-flex align-items-center flex-wrap mt-1">
                  <UserAvatar user={mainArticle.createdBy} size={30} /> {/* ✅ API key: createdBy */}
                  <small className="ms-2">{mainArticle.createdBy?.name || "EMS News"} | {getDate(mainArticle.createdAt)}</small> {/* ✅ API key: createdAt */}
                </div>
              </div>
            </Link>
          )}

          {bottomArticle && (
            <Link to={`/news/${bottomArticle.slug_en}`} key={bottomArticle.slug_en} state={{ relatedArticles: newsData }} style={linkStyle}>
              <Row className="align-items-center gx-2">
                <Col xs={4} md={3}>
                  <Image
                    src={bottomArticle.media?.[0]?.url || "https://via.placeholder.com/120x80"} // ✅ API key: media[0].url
                    fluid
                    rounded
                  />
                </Col>
                <Col xs={8} md={9} className="ps-2">
                  <p className="fw-bold mb-1">{bottomArticle.title_hi || bottomArticle.title_en}</p> {/* ✅ API key: title_hi fallback title_en */}
                  <div className="d-flex align-items-center flex-wrap">
                    <UserAvatar user={bottomArticle.createdBy} size={25} /> {/* ✅ API key: createdBy */}
                    <small className="ms-2 text-muted">{bottomArticle.createdBy?.name || "EMS News"} | {getDate(bottomArticle.createdAt)}</small>
                  </div>
                </Col>
              </Row>
            </Link>
          )}
        </Col>

        {/* Right Column */}
        <Col lg={5}>
          {sideArticles.map((article) => (
            <Link to={`/news/${article.slug_en}`} key={article.slug_en} state={{ relatedArticles: newsData }} style={linkStyle}>
              <Row className="align-items-center gx-2 mb-3">
                <Col xs={4}>
                  <Image src={article.media?.[0]?.url || "https://via.placeholder.com/120x80"} fluid rounded /> {/* ✅ API key: media[0].url */}
                </Col>
                <Col xs={8} className="ps-2">
                  <p className="fw-bold mb-1" style={{ fontSize: "0.9rem", lineHeight: "1.4" }}>{article.title_hi || article.title_en}</p> {/* ✅ API key: title_hi fallback title_en */}
                  <div className="d-flex align-items-center flex-wrap">
                    <UserAvatar user={article.createdBy} size={25} /> {/* ✅ API key: createdBy */}
                    <small className="text-muted ms-1">{article.createdBy?.name || "EMS News"} | {getDate(article.createdAt)}</small>
                  </div>
                </Col>
              </Row>
            </Link>
          ))}
        </Col>
      </Row>
    </Container>
  );
};

export default Manoranjan;
