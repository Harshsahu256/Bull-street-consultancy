
// import React, { useState, useEffect } from "react";
// import { Container, Row, Col, Spinner, Image, Button } from "react-bootstrap";
// import { FaPlayCircle } from "react-icons/fa";
// import { getVideo } from "../../../Services/authApi";
// import { useNavigate } from "react-router-dom";

// const VideoCard = ({ thumbnail, onClick, title }) => (
//   <div
//     className="position-relative mb-3 shadow-sm"
//     onClick={onClick}
//     style={{
//       cursor: "pointer",
//       borderRadius: "10px",
//       overflow: "hidden",
//       transition: "transform 0.2s ease-in-out",
//     }}
//   >
//     <div style={{ position: "relative", width: "100%", paddingTop: "56.25%" }}>
//       <Image
//         src={thumbnail}
//         alt="Video Thumbnail"
//         fluid
//         style={{
//           position: "absolute",
//           top: 0,
//           left: 0,
//           width: "100%",
//           height: "100%",
//           objectFit: "cover",
//           objectPosition: "center",
//           filter: "brightness(85%)",
//         }}
//       />
//       <FaPlayCircle
//         color="#ffffff"
//         size={36}
//         className="position-absolute top-50 start-50 translate-middle"
//         style={{
//           opacity: 0.9,
//           filter: "drop-shadow(0px 0px 6px rgba(0,0,0,0.6))",
//         }}
//       />
//     </div>
//     <div className="p-2 fw-bold text-truncate">{title}</div>
//   </div>
// );

// const EmstvPage = () => {
//   const [videos, setVideos] = useState([]);
//   const [isLoading, setIsLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [selectedCategory, setSelectedCategory] = useState("All");
//   const navigate = useNavigate();

//   useEffect(() => {
//     window.scrollTo(0, 0); // Scroll to top when component mounts
//     getVideo()
//       .then((res) => {
//         const data = res?.data || [];
//         setVideos(data);
//       })
//       .catch((err) => {
//         setError("Failed to load videos");
//         console.error(err);
//       })
//       .finally(() => setIsLoading(false));
//   }, []);

//   // Unique categories निकालो
//   const categories = ["All", ...new Set(videos.map((v) => v.category_name))];

//   // Selected category की videos
//   const filteredVideos =
//     selectedCategory === "All"
//       ? videos
//       : videos.filter((v) => v.category_name === selectedCategory);

//   const getThumbnailUrl = (url) => {
//     if (!url) return "";
//     let videoId = "";
//     if (url.includes("youtu.be")) videoId = url.split("/").pop().split("?")[0];
//     else if (url.includes("youtube.com/watch"))
//       videoId = new URL(url).searchParams.get("v");
//     return videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : "";
//   };

//   if (isLoading)
//     return (
//       <div className="text-center my-4">
//         <Spinner animation="border" size="sm" />
//       </div>
//     );
//   if (error) return <div className="text-center text-danger my-4">{error}</div>;

//   return (
//     <Container className="mt-4">
//       {/* EMS TV Heading */}
//       <div className="d-flex align-items-center mb-3 flex-wrap">
//         <div className="d-flex align-items-center flex-shrink-0 mb-2 mb-sm-0">
//           <div
//             style={{ width: "7px", height: "35px", backgroundColor: "#C00000" }}
//             className="me-2"
//           ></div>
//           <h2 className="fw-bold m-0">EMS TV</h2>
//         </div>
//         <hr className="flex-grow-1 mx-2 mx-sm-3 border-danger border-2 opacity-100 my-0" />
//       </div>

//       {/* ✅ Categories Tabs */}
//       <div className="d-flex flex-wrap gap-2 mb-3">
//         {categories.map((cat) => (
//           <Button
//             key={cat}
//             variant={selectedCategory === cat ? "danger" : "outline-danger"}
//             size="sm"
//             onClick={() => setSelectedCategory(cat)}
//           >
//             {cat}
//           </Button>
//         ))}
//       </div>

//       {/* ✅ Videos Grid */}
//       <Row className="g-3">
//         {filteredVideos.map((video) => (
//           <Col key={video._id} xs={12} sm={6} md={4} lg={3}>
//             <VideoCard
//               thumbnail={getThumbnailUrl(video.videoUrl)}
//               title={video.title}
//               onClick={() => {
//                 navigate(`/video/${video._id}`, {
//                   state: { videos, currentVideo: video },
//                 });
//                 window.scrollTo({ top: 0, behavior: "smooth" });
//               }}
//             />
//           </Col>
//         ))}
//       </Row>
//     </Container>
//   );
// };

// export default EmstvPage;


import React, { useState, useEffect } from "react";
import { Container, Row, Col, Spinner, Image, Button } from "react-bootstrap";
import { FaPlayCircle } from "react-icons/fa";
import { getVideo } from "../../../Services/authApi";
import { useNavigate } from "react-router-dom";

const VideoCard = ({ thumbnail, onClick, title }) => (
  <div
    className="position-relative mb-3 shadow-sm video-card"
    onClick={onClick}
    style={{
      cursor: "pointer",
      borderRadius: "10px",
      overflow: "hidden",
      transition: "transform 0.2s ease-in-out",
    }}
  >
    <div style={{ position: "relative", width: "100%", paddingTop: "56.25%" }}>
      <Image
        src={thumbnail}
        alt="Video Thumbnail"
        fluid
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          objectPosition: "center",
          filter: "brightness(85%)",
        }}
      />
      <FaPlayCircle
        color="#ffffff"
        size={36}
        className="position-absolute top-50 start-50 translate-middle"
        style={{
          opacity: 0.9,
          filter: "drop-shadow(0px 0px 6px rgba(0,0,0,0.6))",
        }}
      />
    </div>
    <div className="p-2 fw-bold text-truncate video-title">{title}</div>
  </div>
);

const EmstvPage = () => {
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to top when component mounts
    getVideo()
      .then((res) => {
        const data = res?.data || [];
        setVideos(data);
      })
      .catch((err) => {
        setError("Failed to load videos");
        console.error(err);
      })
      .finally(() => setIsLoading(false));
  }, []);

  // Unique categories निकालो
  const categories = ["All", ...new Set(videos.map((v) => v.category_name))];

  // Selected category की videos
  const filteredVideos =
    selectedCategory === "All"
      ? videos
      : videos.filter((v) => v.category_name === selectedCategory);

  const getThumbnailUrl = (url) => {
    if (!url) return "";
    let videoId = "";
    if (url.includes("youtu.be")) videoId = url.split("/").pop().split("?")[0];
    else if (url.includes("youtube.com/watch"))
      videoId = new URL(url).searchParams.get("v");
    return videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : "";
  };

  if (isLoading)
    return (
      <div className="text-center my-4">
        <Spinner animation="border" size="sm" />
      </div>
    );
  if (error) return <div className="text-center text-danger my-4">{error}</div>;

  return (
    <Container className="mt-4">
      {/* EMS TV Heading */}
      <div className="d-flex align-items-center mb-3 flex-wrap">
        <div className="d-flex align-items-center flex-shrink-0 mb-2 mb-sm-0">
          <div
            style={{ width: "7px", height: "35px", backgroundColor: "#C00000" }}
            className="me-2"
          ></div>
          <h2 className="fw-bold m-0">EMS TV</h2>
        </div>
        <hr className="flex-grow-1 mx-2 mx-sm-3 border-danger border-2 opacity-100 my-0" />
      </div>

      {/* ✅ Categories Tabs */}
      <div className="d-flex flex-wrap gap-2 mb-3">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "danger" : "outline-danger"}
            size="sm"
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* ✅ Videos Grid */}
      <Row className="g-3">
        {filteredVideos.map((video) => (
          <Col key={video._id} xs={12} sm={6} md={4} lg={3}>
            <VideoCard
              thumbnail={getThumbnailUrl(video.videoUrl)}
              title={video.title}
              onClick={() => {
                navigate(`/video/${video._id}`, {
                  state: { videos, currentVideo: video },
                });
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            />
          </Col>
        ))}
      </Row>

      {/* ✅ Extra Mobile Styling */}
      <style>{`
        @media (max-width: 576px) {
          .video-card {
            margin-bottom: 15px;
          }
          .video-title {
            font-size: 14px;
            white-space: normal;
          }
        }
      `}</style>
    </Container>
  );
};

export default EmstvPage;
