// import React from "react";
// import { Container, Row, Col, Card, Carousel } from "react-bootstrap";
// import { Link } from "react-router-dom";

// // ✅ Assets folder से images import करें
// import jabalpurThumb from "../assets/jabalpur-thumb-1.jpg";  
// import chhindwaraThumb from "../assets/chhindwara-thumb.jpg";
// import balaghatThumb from "../assets/balaghat-thumb.jpg";
// import seoniThumb from "../assets/seoni-thumb.jpg";
// import mandlaThumb from "../assets/mandla-thumb.jpg";
// import narsinghpurThumb from "../assets/narsinghpur-thumb.jpg";

// // Data with editions
// const epaperEditions = {
//   jabalpurExpress: [
//     { id: 1, name: 'Jabalpur Page 1', thumbnail: mandlaThumb },
//     { id: 2, name: 'Seoni Page 2', thumbnail: seoniThumb },
//     { id: 3, name: 'Balaghat Page 3', thumbnail: balaghatThumb },
//   ],
//   expressNews: [
//     { id: 4, name: 'Mandla Page 1', thumbnail: mandlaThumb },
//     { id: 5, name: 'Narsinghpur Page 2', thumbnail: narsinghpurThumb },
//   ],
// };

// // Gallery Section
// const GallerySection = ({ title, editions }) => (
//   <>
//     <h4 className="fw-bold border-bottom pb-2 mb-3 mt-4">{title}</h4>
//     <Row xs={2} md={4} lg={6} className="g-4">
//       {editions.map((edition) => (
//         <Col key={edition.id}>
//           <Link to={`/epaper/viewer/${edition.id}`} className="text-decoration-none">
//             <Card className="text-center shadow-sm h-100">
//               <div style={{ height: "200px", display: "flex", alignItems: "center", justifyContent: "center", padding: "10px", backgroundColor: "#f8f9fa" }}>
//                 <Card.Img variant="top" src={edition.thumbnail} style={{ maxHeight: "100%", maxWidth: "100%", objectFit: "contain" }}/>
//               </div>
//               <Card.Footer className="p-2">
//                 <h6 className="fw-bold text-dark mb-0">{edition.name}</h6>
//               </Card.Footer>
//             </Card>
//           </Link>
//         </Col>
//       ))}
//     </Row>
//   </>
// );

// const EpaperGallery = () => {
//   return (
//     <Container fluid className="p-0 directory-page">
//       <Carousel indicators={false} style={{ backgroundColor: "#214660", color: "white" }}>
//         <Carousel.Item>
//           <Container className="p-5">
//             <Row className="align-items-center justify-content-center text-center">
//               <Col md={8}>
//                 <h3>EMS Express</h3>
//                 <p>Ems Express, the leading newspaper of Mahakoshal territory...</p>
//                 <h5 className="mt-2">महाकौशल का विश्वसनीय समाचार पत्र</h5>
//               </Col>
//             </Row>
//           </Container>
//         </Carousel.Item>
//       </Carousel>
//       <Container className="my-4">
//         { epaperEditions.jabalpurExpress.length > 0 && 
//           <GallerySection title="Jabalpur Express" editions={epaperEditions.jabalpurExpress} />
//         }
//         { epaperEditions.expressNews.length > 0 && 
//           <GallerySection title="Express News" editions={epaperEditions.expressNews} /> 
//         }
//       </Container>
//     </Container>
//   );
// };

// export default EpaperGallery;


import React from 'react';
import { Container, Row, Col, Card, Carousel } from 'react-bootstrap';
import { Link } from 'react-router-dom';

// ✅ Assets folder से images import करें
import jabalpurThumb from '../assets/jabalpur-thumb-1.jpg';  
import chhindwaraThumb from '../assets/chhindwara-thumb.jpg';
import balaghatThumb from '../assets/balaghat-thumb.jpg';
import seoniThumb from '../assets/seoni-thumb.jpg';
import mandlaThumb from '../assets/mandla-thumb.jpg';
import narsinghpurThumb from '../assets/narsinghpur-thumb.jpg';

// Data with editions
const epaperEditions = {
  jabalpurExpress: [
    { id: 1, name: 'Jabalpur Page 1', thumbnail: mandlaThumb },
    { id: 2, name: 'Seoni Page 2', thumbnail: seoniThumb },
    { id: 3, name: 'Balaghat Page 3', thumbnail: balaghatThumb },
  ],
  expressNews: [
    { id: 4, name: 'Mandla Page 1', thumbnail: mandlaThumb },
    { id: 5, name: 'Narsinghpur Page 2', thumbnail: narsinghpurThumb },
  ],
};

// Gallery Section
const GallerySection = ({ title, editions }) => (
  <>
    <h4 className="fw-bold border-bottom pb-2 mb-3 mt-4">{title}</h4>
    <Row xs={2} md={4} lg={6} className="g-4">
      {editions.map((edition) => (
        <Col key={edition.id}>
          <Link to={`/epaper/viewer/${edition.id}`} className="text-decoration-none">
            <Card className="text-center shadow-sm h-100">
              <div style={{ height: "200px", display: "flex", alignItems: "center", justifyContent: "center", padding: "10px", backgroundColor: "#f8f9fa" }}>
                <Card.Img variant="top" src={edition.thumbnail} style={{ maxHeight: "100%", maxWidth: "100%", objectFit: "contain" }}/>
              </div>
              <Card.Footer className="p-2">
                <h6 className="fw-bold text-dark mb-0">{edition.name}</h6>
              </Card.Footer>
            </Card>
          </Link>
        </Col>
      ))}
    </Row>
  </>
);

const EpaperGallery = () => {
  React.useEffect(() => {
    // Apply overflow-x: hidden to html and body when the component mounts
    document.documentElement.style.overflowX = 'hidden';
    document.body.style.overflowX = 'hidden';

    // Clean up the style when the component unmounts
    return () => {
      document.documentElement.style.overflowX = '';
      document.body.style.overflowX = '';
    };
  }, []); // Empty dependency array ensures this runs only once on mount and unmount

  return (
    <Container fluid className="p-0 directory-page">
      {/* Global CSS to prevent horizontal scroll */}
      <style type="text/css">
        {`
          html, body {
            overflow-x: hidden;
            width: 100%;
          }
          .directory-page {
            width: 100vw;
          }
        `}
      </style>
      <Carousel indicators={false} style={{ backgroundColor: "#214660", color: "white" }}>
        <Carousel.Item>
          <Container className="p-5">
            <Row className="align-items-center justify-content-center text-center">
              <Col md={8}>
                <h3>EMS Express</h3>
                <p>Ems Express, the leading newspaper of Mahakoshal territory...</p>
                <h5 className="mt-2">महाकौशल का विश्वसनीय समाचार पत्र</h5>
              </Col>
            </Row>
          </Container>
        </Carousel.Item>
      </Carousel>
      <Container className="my-4">
        { epaperEditions.jabalpurExpress.length > 0 && 
          <GallerySection title="Jabalpur Express" editions={epaperEditions.jabalpurExpress} />
        }
        { epaperEditions.expressNews.length > 0 && 
          <GallerySection title="Express News" editions={epaperEditions.expressNews} /> 
        }
      </Container>
    </Container>
  );
};

export default EpaperGallery;